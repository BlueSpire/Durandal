define(function(){
    return {
        someProperty:'This is being bound against an inline view.'
    };
});