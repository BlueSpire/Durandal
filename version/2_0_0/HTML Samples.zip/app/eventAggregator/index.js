﻿define(['./publisher', './subscriber'], function (publisher, subscriber) {
    return {
        publisher:publisher,
        subscriber: subscriber
    };
});