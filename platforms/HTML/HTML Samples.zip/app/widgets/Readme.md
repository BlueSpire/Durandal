﻿# Note
Expander is a demo widget.
It was created solely for the sample, to teach the basic strategy for widget creation.